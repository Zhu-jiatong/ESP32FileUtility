/*
 Name:		FileUtility.cpp
 Created:	3/16/2023 2:49:45 PM
 Author:	jiaji
 Editor:	http://www.visualmicro.com
*/

#include "FileUtility.h"

FileUtility::FileUtility(FS& fs, const char* path)
	: m_fs(fs), m_file(new File(m_fs.open(path)), [](File* ptr) {delete ptr; })
{}

FileUtility::FileUtility(FS& fs, File& file)
	: m_fs(fs), m_file(&file, [](File* ptr) {})
{}

FileUtility::FileUtility(const FileUtility& other)
	:m_fs(other.m_fs), m_file(other.m_file)
{}

FileUtility::~FileUtility()
{
}

FileUtility& FileUtility::operator=(const FileUtility& other)
{
	if (this != &other)
	{
		m_fs = other.m_fs;
		m_file = other.m_file;
	}
	return *this;
}

FileUtility::operator File& ()
{
	return *m_file;
}

FileUtility::operator bool() const
{
	return *m_file;
}

void FileUtility::forEachFile(DirectoryIteratorCallback f, const char* openMode)
{
	for (File entry = m_file->openNextFile(openMode); entry; entry = m_file->openNextFile(openMode))
		f(entry);
}

void FileUtility::forEachFileRecursive(DirectoryIteratorCallback f, const char* openMode)
{
	std::stack<const char*> directories({ m_file->path() });

	DirectoryIteratorCallback recursiveIteratorCallback = [&](File& entry)
	{
		if (entry.isDirectory())
			directories.emplace(entry.path());

		f(entry);
	};

	while (!directories.empty())
	{
		const char* currentEntryPath = directories.top();
		directories.pop();

		FileUtility currentEntry(m_fs, currentEntryPath);
		currentEntry.forEachFile(recursiveIteratorCallback);
	}
}

bool FileUtility::renameTo(const String& newName)
{
	const String pathFrom = m_file->path();
	int seperatorIndex = pathFrom.lastIndexOf("/");
	String parentPath = pathFrom.substring(0, seperatorIndex);
	String pathTo = parentPath + "/" + newName;
	return m_fs.rename(pathFrom, pathTo);
}

bool FileUtility::moveTo(const String& pathTo)
{
	String pathFrom = m_file->path();
	return m_fs.rename(pathFrom, pathTo);
}

bool FileUtility::del()
{
	if (!m_file->isDirectory())
		return m_fs.remove(m_file->path());

	// from this point onwards, m_file can only be a directory
	bool result = true;
	DirectoryIteratorCallback recursiveDelete = [&](File& entry)
	{
		if (entry.isDirectory())
			result &= m_fs.rmdir(entry.path());
		else
			result &= m_fs.remove(entry.path());
	};
	forEachFileRecursive(recursiveDelete);

	// from this point onwards, m_file can only be an EMPTY directory
	result &= m_fs.rmdir(m_file->path());
	return result;
}

FileUtility FileUtility::parentPath()
{
	String path = m_file->path();
	int lastIndex = path.lastIndexOf('/');
	if (lastIndex == -1)
		throw std::runtime_error(("\"" + path + "\" has no parent path").c_str());
	if (lastIndex == 0)
		return { m_fs, "/" };
	return { m_fs, path.substring(0, lastIndex).c_str() };
}
