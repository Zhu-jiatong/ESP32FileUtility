/*
 Name:		DirectoryIterator.cpp
 Created:	4/3/2023 11:46:45 AM
 Author:	jiaji
 Editor:	http://www.visualmicro.com
*/

#include "FileUtility.h"


FileUtility::DirectoryIterator::DirectoryIterator(FileUtility& root, const char* openMode)
	:m_openMode(openMode), m_root(root)
{
	File& internalFile = static_cast<File&>(m_root);

	if (!internalFile.isDirectory())
		throw std::runtime_error("Is not directory");

	File* newEntry = new File(internalFile.openNextFile(m_openMode));
	m_entry.reset(new FileUtility(*m_root.m_fs, newEntry));
}
